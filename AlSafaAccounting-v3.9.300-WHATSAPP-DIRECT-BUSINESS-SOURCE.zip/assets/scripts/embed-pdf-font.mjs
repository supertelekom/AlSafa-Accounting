import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const font = readFileSync(resolve(root, 'vendor', 'DejaVuSans.ttf')).toString('base64');
writeFileSync(resolve(root, 'vendor', 'pdf-font-data.js'), `window.__ALSAFA_PDF_FONT_BASE64=${JSON.stringify(font)};\n`);
