import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import aapt from 'aaptjs3';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const apktool = join(root, 'node_modules', 'apktool-jar', 'bin', 'apktool_2.4.1.jar');
const signer = join(root, 'node_modules', 'nitron', 'vendor', 'uber-apk-signer.jar');
const template = join(root, 'node_modules', 'nitron', 'template', 'base.apk');
const smali = join(root, 'native', 'smali');
const sourceApk = join(root, 'dist', 'app.apk');
const finalApk = join(root, 'dist', 'AlSafaAccounting-v3.9.85-CITIZEN-CERRUTI-LOOKUP-UNSIGNED-KEY.apk');
const work = mkdtempSync(join(tmpdir(), 'alsafa-reliability-'));

const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.alsafa.watch"
    android:versionCode="31000"
    android:versionName="3.9.85">
    <queries>
        <package android:name="com.whatsapp.w4b" />
    </queries>
    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="34" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <application
        android:allowBackup="true"
        android:hardwareAccelerated="true"
        android:label="محاسبة الصفا"
        android:usesCleartextTraffic="true">
        <activity
            android:name="com.nicron.webview.MainActivity"
            android:configChanges="keyboardHidden|orientation|screenSize"
            android:exported="true"
            android:screenOrientation="unspecified">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <provider
            android:name="com.nicron.webview.PdfShareProvider"
            android:authorities="com.alsafa.watch.pdfshare"
            android:exported="false"
            android:grantUriPermissions="true" />
    </application>
</manifest>`;

try {
  const decoded = join(work, 'decoded');
  const wrapper = join(work, 'native-wrapper.apk');
  const manifestXml = join(work, 'AndroidManifest.xml');
  const platformJar = join(work, 'android.jar');
  const manifestApk = join(work, 'manifest.apk');
  const unsigned = join(work, 'unsigned.apk');
  const signed = join(work, 'signed');

  // The Nitron template intentionally has no Android resource table.  Build
  // the native code separately, then use AAPT2 to produce a valid binary
  // manifest (including the PDF content provider) before merging it into the
  // generated app package.
  execFileSync('java', ['-jar', apktool, 'd', '-f', template, '-o', decoded], { stdio: 'inherit' });
  execFileSync('cp', ['-R', `${smali}/.`, join(decoded, 'smali')]);
  execFileSync('java', ['-jar', apktool, 'b', decoded, '-o', wrapper], { stdio: 'inherit' });
  const dex = execFileSync('unzip', ['-p', wrapper, 'classes.dex']);

  writeFileSync(manifestXml, manifest);
  writeFileSync(platformJar, execFileSync(
    'unzip',
    ['-p', apktool, 'brut/androlib/android-framework.jar'],
    { maxBuffer: 16 * 1024 * 1024 }
  ));
  execFileSync(aapt.getBinPath(), [
    'link', '-o', manifestApk, '--manifest', manifestXml, '-I', platformJar,
    '--min-sdk-version', '21', '--target-sdk-version', '34'
  ], { stdio: 'inherit' });

  const source = await JSZip.loadAsync(readFileSync(sourceApk));
  const compiledManifest = await JSZip.loadAsync(readFileSync(manifestApk));
  const manifestEntry = compiledManifest.file('AndroidManifest.xml');
  if (!manifestEntry) throw new Error('Compiled Android manifest was not created.');

  for (const name of Object.keys(source.files)) {
    if (name === 'AndroidManifest.xml' || name === 'classes.dex' || name === 'resources.arsc' || name.startsWith('META-INF/')) source.remove(name);
  }
  source.file('AndroidManifest.xml', await manifestEntry.async('nodebuffer'), { compression: 'STORE' });
  source.file('classes.dex', dex, { compression: 'STORE' });
  writeFileSync(unsigned, await source.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));

  execFileSync('java', ['-jar', signer, '-a', unsigned, '-o', signed], { stdio: 'inherit' });
  const signedFile = readdirSync(signed).find(file => file.endsWith('.apk'));
  if (!signedFile) throw new Error('Signed APK was not created');
  writeFileSync(finalApk, readFileSync(join(signed, signedFile)));
  console.log(`Reliability-fix APK created: ${finalApk}`);
} finally {
  rmSync(work, { recursive: true, force: true });
}
