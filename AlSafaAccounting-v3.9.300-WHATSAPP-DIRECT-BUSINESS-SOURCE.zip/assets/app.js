import { app } from 'nitron'

app.init({
  name: 'محاسبة الصفا',
  packageId: 'com.alsafa.watch',
  version: '3.2.25',
  entry: 'index.html',
  orientation: 'auto',
  statusBar: true,
  permissions: ['INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA'],
  icon: './icon.svg'
})
