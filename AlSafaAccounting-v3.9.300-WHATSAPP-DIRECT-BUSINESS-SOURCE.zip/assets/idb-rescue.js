const out=document.getElementById('out'), status=document.getElementById('status');
const esc=s=>String(s??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function card(t,c=''){out.insertAdjacentHTML('beforeend',`<div class="card ${c}">${esc(t)}</div>`)}
async function getExisting(){
 let names=[];
 try{ if(indexedDB.databases) names=(await indexedDB.databases()).map(x=>x.name).filter(Boolean); }catch(e){}
 if(!names.includes('alsafa_purchase_drafts_v2')) names.push('alsafa_purchase_drafts_v2');
 const found=[];
 for(const name of names){
  try{
   let created=false;
   const db=await new Promise((res,rej)=>{const r=indexedDB.open(name);r.onupgradeneeded=()=>{created=true};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
   if(created){db.close();try{indexedDB.deleteDatabase(name)}catch(_){};continue;}
   for(const st of Array.from(db.objectStoreNames)){
    try{
     const vals=await new Promise((res,rej)=>{const tx=db.transaction(st,'readonly'),rq=tx.objectStore(st).getAll();rq.onsuccess=()=>res(rq.result||[]);rq.onerror=()=>rej(rq.error)});
     vals.forEach((v,i)=>{if(v&&typeof v==='object'&&(v.rowControls||v.controls||v.rowCount))found.push({name,st,i,v})});
    }catch(e){}
   }
   db.close();
  }catch(e){}
 }
 return found;
}
function summarize(v){let names=[]; try{for(const row of (v.rowControls||[])){for(const x of row||[]){if(/name|item|product/i.test(x?.name||'')&&x?.value)names.push(x.value)}}}catch(_){};return `rowCount=${v.rowCount||v.rowControls?.length||0}\nوقت=${v.at?new Date(v.at).toLocaleString('ar'):'غير معروف'}\n${names.slice(0,12).join('\n')}`}
function xhrBytes(url){return new Promise(resolve=>{try{const x=new XMLHttpRequest();x.open('GET',url,true);x.responseType='arraybuffer';x.timeout=1200;x.onload=()=>resolve(x.status===0&&x.response?new Uint8Array(x.response):null);x.onerror=x.ontimeout=()=>resolve(null);x.send()}catch(e){resolve(null)}})}
function textViews(b){let a='';try{a=new TextDecoder('utf-8',{fatal:false}).decode(b)}catch(_){};let u='';try{u=new TextDecoder('utf-16le',{fatal:false}).decode(b)}catch(_){};return [a,u]}
async function rawScan(){
 const bases=['file:///data/user/0/com.alsafa.watch/app_webview/Default/IndexedDB/file__0.indexeddb.leveldb/','file:///data/data/com.alsafa.watch/app_webview/Default/IndexedDB/file__0.indexeddb.leveldb/'];
 let hits=[], files=[]; const nums=[]; for(let i=1;i<=800;i++)nums.push(String(i).padStart(6,'0'));
 for(const base of bases){
  for(let p=0;p<nums.length;p+=40){const batch=[];for(const n of nums.slice(p,p+40))for(const ext of ['.log','.ldb','.sst'])batch.push((async()=>{const b=await xhrBytes(base+n+ext);if(!b)return;files.push({base,n:n+ext,size:b.length});for(const txt of textViews(b)){if(/rowControls|supplierInvoice|alsafa_purchase_drafts_v2|purchase_form_draft|جمال|011226/.test(txt)){let at=Math.max(txt.indexOf('rowControls'),txt.indexOf('supplierInvoice'),txt.indexOf('جمال'),txt.indexOf('011226'));if(at<0)at=0;hits.push({file:n+ext,size:b.length,ctx:txt.slice(Math.max(0,at-1800),at+10000)});break}}})());await Promise.all(batch)}
  if(files.length)break;
 }
 return {files,hits};
}
(async()=>{
 const f=await getExisting(); if(f.length){status.textContent=`وجدت ${f.length} مسودة فعلية قبل فتح شاشة الفاتورة.`;f.forEach((x,i)=>card(`#${i+1} ${x.name}/${x.st}\n${summarize(x.v)}`,'ok'));return}
 status.textContent='لا توجد مسودة نشطة عبر IndexedDB API. جارٍ الآن فحص ملفات IndexedDB الخام بحثاً عن النسخة المحذوفة…';
 const r=await rawScan(); status.textContent=`انتهى الفحص الخام. ملفات IndexedDB المقروءة: ${r.files.length} — آثار مسودة: ${r.hits.length}`;
 if(!r.files.length)card('لم يستطع WebView قراءة مسار ملفات IndexedDB الخام. لا يعني هذا أن البيانات غير موجودة.','bad');
 r.hits.forEach((h,i)=>card(`#${i+1} ${h.file} (${h.size} بايت)\n${h.ctx}`,'ok'));
 if(r.files.length&&!r.hits.length)card('تم الوصول لملفات IndexedDB لكن لم يظهر نص واضح للمسودة ضمن الملفات 000001–000800.','bad');
})();
